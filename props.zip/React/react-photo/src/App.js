import React, { useState } from 'react';
import Title from './components/title';
import UploadPhoto from './components/uploadPhoto';
import Model from './components/Model';
import ImageGrid from './components/imageGrid';

function App() {
	const [selectedImage, setSelectedImage] = useState(null);
	return (
		<div className="App">
			<Title />
			<UploadPhoto />
			<ImageGrid setSelectedImage={setSelectedImage} />
			{selectedImage && <Model selectedImage={selectedImage} setSelectedImage={setSelectedImage} />}
		</div>
	);
}

export default App;
