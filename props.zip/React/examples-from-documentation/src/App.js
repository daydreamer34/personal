import React from 'react';
import RefTried from './components/ref-tried';
const App = () => {
	return (
		<div>
			{/* <RefTried /> */}
			<BlurExample />
			Hello
		</div>
	);
};

export default App;
