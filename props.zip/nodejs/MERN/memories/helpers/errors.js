const errorHandler = (res, error) => {
	res.status(error.code ? error.code : 404).json({ status: error.status ? error.status : 'Failure', ...error });
};

export default errorHandler;
