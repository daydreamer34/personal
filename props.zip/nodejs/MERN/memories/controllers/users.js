import errorHandler from '../helpers/errors.js';
import Users from '../models/users.js';

export const getUsers = async (req, res) => {
	try {
		const users = await Users.find();
		res.status(200).json(users);
	} catch (error) {
		errorHandler(res, error);
	}
};

export const createUsers = async (req, res) => {
	const { first_name, last_name, user_name, email, password } = req.body;
	try {
		const userModel = new Users({ first_name, last_name, user_name, email, password });
		await userModel.save();
		res.status(201).json(userModel);
	} catch (error) {
		errorHandler(res, { ...error, code: 409 });
	}
};
