import mongoose from 'mongoose';
import PostMessage from '../models/postMessage.js';
import errorHandler from '../helpers/errors.js';

export const getPost = async (req, res) => {
	const { id: _id } = req.params;
	try {
		if (!mongoose.Types.ObjectId.isValid(_id)) errorHandler(res, { code: 404, message: `The given id: ${_id} in the request is not vaild!` });
		const postMessage = await PostMessage.findById(_id);
		res.status(200).json(postMessage);
	} catch (error) {
		errorHandler(res, error);
	}
};

export const getPosts = async (req, res) => {
	try {
		const postMessages = await PostMessage.find();
		res.status(200).json(postMessages);
	} catch (error) {
		errorHandler(res, error);
	}
};

export const createPost = async (req, res) => {
	const { creator, title, message, tags, selectedFile } = req.body;
	try {
		if (!(creator && title && message && tags && selectedFile)) errorHandler(res, { code: 400, message: 'Some expeted elements missing form the request' });
		const postModel = new PostMessage({ creator, title, message, tags, selectedFile });
		await postModel.save();
		res.status(201).json(postModel);
	} catch (error) {
		errorHandler(res, { ...error, code: 409 });
	}
};

export const updatePost = async (req, res) => {
	const { id: _id } = req.params;
	const { creator, title, message, tags, selectedFile } = req.body;
	try {
		if (!mongoose.Types.ObjectId.isValid(_id)) errorHandler(res, { code: 404, message: `The given id: ${_id} in the request is not vaild!` });
		const postMessage = await PostMessage.findByIdAndUpdate(_id, { creator, title, message, tags, selectedFile, _id }, { new: true });
		res.status(200).json(postMessage);
	} catch (error) {
		errorHandler(res, error);
	}
};

export const deletePost = async (req, res) => {
	const { id: _id } = req.params;
	try {
		if (!mongoose.Types.ObjectId.isValid(_id)) errorHandler(res, { code: 404, message: `The given id: ${_id} in the request is not vaild!` });
		const postMessage = await PostMessage.findByIdAndDelete(_id);
		res.status(202).json(postMessage);
	} catch (error) {
		errorHandler(res, error);
	}
};

export const likePost = async (req, res) => {
	const { id: _id } = req.params;
	try {
		if (!mongoose.Types.ObjectId.isValid(_id)) errorHandler({ code: 404, message: `The given id: ${_id} in the request is not vaild!` });
		const postMessage = await PostMessage.findById(_id);
		const updatedPostMessage = await PostMessage.findByIdAndUpdate(_id, { likedCount: postMessage.likedCount + 1 }, { new: true });
		res.status(200).json(updatedPostMessage);
	} catch (error) {
		errorHandler(res, error);
	}
};
