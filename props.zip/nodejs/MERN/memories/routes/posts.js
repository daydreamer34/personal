import express from 'express';
import * as controllers from '../controllers/posts.js';

const router = express.Router();

router.get('/', controllers.getPosts);
router.get('/:id', controllers.getPost);
router.post('/', controllers.createPost);
router.patch('/:id', controllers.updatePost);
router.delete('/:id', controllers.deletePost);
router.patch('/:id/likePost', controllers.likePost);

export default router;
