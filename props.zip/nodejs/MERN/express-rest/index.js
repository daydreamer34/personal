import express from 'express';
import productsRoutes from './routes/products.js';
import usersRoutes from './routes/users.js';
import homeRoutes from './routes/home.js';

const app = express();
const PORT = process.env.PORT || 5001;
app.use(express.json());
app.use('/', homeRoutes);

app.use('/products', productsRoutes);
app.use('/users', usersRoutes);

app.listen(PORT, () => {
	console.log(`App is running on port: http://localhost:${PORT}/`);
});
