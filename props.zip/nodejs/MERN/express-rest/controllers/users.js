const users = [
	{
		firstName: 'Selvakumar',
		lastName: 'Kanagaraj',
		age: 34,
	},
];

export const getUsers = (req, res) => {
	try {
		res.status(200).json(users);
	} catch (error) {
		res.status(404).json({ ...error });
	}
};
