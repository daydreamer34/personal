const products = [
	{
		name: 'iPhone 12',
	},
];

export const getProducts = (req, res) => {
	try {
		res.status(200).json(products);
	} catch (error) {
		res.status(404).json(error);
	}
};
