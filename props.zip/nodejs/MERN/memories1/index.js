import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

import postRoutes from './routes/posts.js';

const port = process.env.PORT || 5000;
const connection_url = 'mongodb+srv://daydreamer34:Aks@th_1908@nodeapps.yhbut.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
const app = express();

app.use(cors());

const urlEncodedParser = express.urlencoded({ extended: true, limit: '30mb' });

app.use('/posts', urlEncodedParser, postRoutes);

mongoose
	.connect(connection_url, { useNewUrlParser: true, useUnifiedTopology: true })
	.then(() => {
		app.listen(port, () => {
			console.log(`Application running on: http://localhost:${port}/`);
		});
	})
	.catch((error) => {
		console.log(error);
	});
mongoose.set('useFindAndModify', false);
