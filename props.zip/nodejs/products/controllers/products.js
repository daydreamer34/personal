import * as Product from '../models/products.js';

export const getProducts = async (req, res) => {
	try {
		res.writeHead(200, { 'Content-Type': 'application/json' });
		res.end(JSON.stringify({ status: 'Success', data: await Product.findAll() }));
	} catch (error) {
		res.writeHead(404, { 'Content-Type': 'application/json' });
		res.end(JSON.stringify({ status: 'Failed', ...error }));
	}
};

export const getProduct = async (req, res, id) => {
	try {
		res.writeHead(200, { 'Content-Type': 'application/json' });
		res.end(JSON.stringify({ status: 'Success', data: await Product.findById(id) }));
	} catch (error) {
		res.writeHead(404, { 'Content-Type': 'application/json' });
		res.end(JSON.stringify({ status: 'Failed', ...error }));
	}
};
