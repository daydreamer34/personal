import { readFile } from 'fs/promises';

export const getProducts = async () => {
	const products = JSON.parse(await readFile(new URL('../data/products.json', import.meta.url)));
	return products;
};
