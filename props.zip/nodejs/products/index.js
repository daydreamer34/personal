import http from 'http';
import { getProduct, getProducts } from './controllers/products.js';

const app = http.createServer(async (req, res) => {
	let url = req.url;
	let method = req.method;
	let params = req.url.split('/')[2];
	if (url === '/products' && method === 'GET') {
		await getProducts(req, res);
	}
	if (url.match(/\/products\/\w+/) && method === 'GET') {
		await getProduct(req, res, params);
	} else {
		res.writeHead(404, { 'Content-Type': 'application/json' });
		res.end(
			JSON.stringify({
				Status: 'Page not found',
				message: 'The given route is not defined yet',
			})
		);
	}
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Your app is running on http://localhost:${PORT}`));
