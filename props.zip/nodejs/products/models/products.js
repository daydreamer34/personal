import { getProducts } from '../helpers/utils.js';

export const findAll = async () => {
	try {
		return await getProducts();
	} catch (error) {
		return { ...error };
	}
};

export const findById = async (id) => {
	try {
		const products = await getProducts();
		const product = products.find((product) => product.id === id);
		if (product) return product;
		else throw { message: `Product not found for given id: ${id}` };
	} catch (error) {
		return { ...error };
	}
};
