import express from 'express';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.resolve();
const urlEncodedParser = express.urlencoded({ extended: true, limit: '5kb' });
console.log(path.resolve());
app.use(express.static(__dirname));
app.get('/', urlEncodedParser, (req, res) => {
	res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
	console.log(`Application server started at http://localhost:${PORT}/`);
});
