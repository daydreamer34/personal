console.clear();
const AssetUtils = function () {};

AssetUtils.getGCD = function (width, height) {
	console.log(`${width} x ${height} => ${width % height}`);
	return height == 0 ? width : AssetUtils.getGCD(height, width % height);
};
AssetUtils.getAspectRatio = function (width, height) {
	var returnRatio = '16x9';
	if (width && height) {
		var gcd = AssetUtils.getGCD(width, height);
		console.log(gcd);
		returnRatio = gcd ? width / gcd + 'x' + height / gcd : returnRatio;
	}
	return returnRatio;
};

console.log(AssetUtils.getGCD(721, 541));
console.log(AssetUtils.getAspectRatio(720, 540));
console.log(AssetUtils.getAspectRatio(721, 541));
