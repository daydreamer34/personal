(function(){

    const sayHiMixin = {
        sayHi() {
            console.log(`Hi ${this.name}`);
        },
        sayBye() {
            console.log(`Bye ${this.name}`);
        }
    }

    class User {

        constructor(name) {
            this.name = name;
        }
    }

    Object.assign(User.prototype, sayHiMixin);
    var Selva = new User('Selva');
    console.log(Selva.sayHi());
    console.log(Selva.sayBye());
})()