const quacking = quack => o => Object.assign({}, o, {quack:()=>quack});

const quacker = quacking('Quack!');

//console.log(quacker().quack());


var selva = {
    name: "Selva",
    printName(){ console.log(this.name);} 
}

function test(){
    console.log(this.printName());
}

test.call(selva);
test.apply(selva);
test.bind(selva)();