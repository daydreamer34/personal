const chocolate = {
    hasChcolate: ()=>true
}
const caramelSwirl = {
    hasCaramelSwirl: ()=>true
}
const pecans = {
    hasPecans: ()=>true
}


const iceCream = Object.assign({}, chocolate, caramelSwirl, pecans);

console.log(
    `
    hasChocolate: ${iceCream.hasChcolate()}
    hasCaramelSwirl: ${iceCream.hasCaramelSwirl()}
    hasPecans: ${iceCream.hasPecans()}
    `
);
