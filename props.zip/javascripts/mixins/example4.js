const flying = o=> {
    let isFlying = false;

    return Object.assign(
        {}, 
        o,
        {
            isFlying: () => isFlying,
            fly(){
                isFlying = true;
                return this;
            },
            land(){
                isFlying = false;
                return this;
            }
        }
        );
}

const brid = flying({"now":"flying"});
console.log(brid);
console.log(brid.fly().isFlying());
console.log(brid.land().isFlying());


