(function(){

    let eventMixin = {
        on(eventName, handler){
            if(!this._eventHandlers) this._eventHandlers = {};
            if(!this._eventHandlers[eventName]) this._eventHandlers[eventName] = [];
            console.log(eventName);
            this._eventHandlers[eventName].push(handler);
            console.log(this._eventHandlers);
        },
        trigger(eventName, ...args) {
            console.log(eventName);
            if(!this._eventHandlers || !this._eventHandlers[eventName]) {return;}
            console.log(eventName);
            this._eventHandlers[eventName].forEach(handler=>handler.apply(this, args));
        }

    }

    class Menu {
        choose(value) {
            this.trigger('select',value);
        }
    }

    Object.assign(Menu.prototype, eventMixin);

    var menu = new Menu();

    menu.on('select', value=> console.log(`${value}`));

    menu.choose(123);
})()