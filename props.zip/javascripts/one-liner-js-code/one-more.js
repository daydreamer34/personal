// # 1. Get a random boolean (true/false)
const randomBoolean = () => Math.random() >= 0.5;console.log(randomBoolean());
// # 2. Check if the provided day is a weekday
const isWeekday = (date) => date.getDay() % 6 !== 0;console.log(isWeekday(new Date(2021, 0, 11)));
// # 3. Reverse a string
const reverse = str => str.split('').reverse().join('');reverse('hello world');
// # 4. Check if the current tab is in view / focus
const isBrowserTabInView = () => document.hidden;isBrowserTabInView();
// # 5. Check if a number is even or odd
const isEven = num => num % 2 === 0;console.log(isEven(2));
// # 6. Get the time from a date
const timeFromDate = date => date.toTimeString().slice(0, 8);console.log(timeFromDate(new Date(2021, 0, 10, 17, 30, 0))); 
// # 7. Truncate a number to a fixed decimal point
const toFixed = (n, fixed) => ~~(Math.pow(10, fixed) * n) / Math.pow(10, fixed);// Examples
toFixed(25.198726354, 1);  // 25.1
toFixed(25.198726354, 2);  // 25.19
toFixed(25.198726354, 3);  // 25.198
toFixed(25.198726354, 4);  // 25.1987
toFixed(25.198726354, 5);  // 25.19872
toFixed(25.198726354, 6);  // 25.198726
// # 8. Check if an element is currently in focus
const elementIsInFocus = (el) => (el === document.activeElement);elementIsInFocus(anyElement)
// # 9. Check if the current user has touch events supported
const touchSupported = () => {
      ('ontouchstart' in window || window.DocumentTouch && document instanceof window.DocumentTouch);
}
console.log(touchSupported());
// # 10. Check if the current user is on an Apple device
const isAppleDevice = /Mac|iPod|iPhone|iPad/.test(navigator.platform);console.log(isAppleDevice);
// # 11. Scroll to top of the page
const goToTop = () => window.scrollTo(0, 0);goToTop();
// # 12. Get average value of arguments
const average = (...args) => args.reduce((a, b) => a + b) / args.length;average(1, 2, 3, 4);
// # 13. Convert Fahrenheit / Celsius
const celsiusToFahrenheit = (celsius) => celsius * 9/5 + 32;const fahrenheitToCelsius = (fahrenheit) => (fahrenheit - 32) * 5/9;// Examples
celsiusToFahrenheit(15);    // 59
celsiusToFahrenheit(0);   // 32
celsiusToFahrenheit(-20);   // -4fahrenheitToCelsius(59);    // 15
fahrenheitToCelsius(32);    // 0
