function Animal(name, energy) {
	this.name = name;
	this.energy = energy;
}

Animal.prototype.eat = function (energy) {
	this.energy += energy;
};

function Dog() {
	Animal.call(this, 'Selva', 1);
    this.eat(10);
	console.log();
}
Dog.prototype = Object.create(Animal.prototype);
const dog = new Dog();
