(function () {
	function Person(firstName, lastName) {
		this.firstName = firstName;
		this.lastName = lastName;

		return this;
	}

	//Person.prototype.isAdult = function() { return true; }
	Person.prototype.isAdult = () => {
		if (this.age > 19) {
			return true;
		}
	};
	const person = new Person('Selvakumar', 'Kanagaraj');
	person.age = 29;

	console.log(person.isAdult());
	console.log(person);
	console.log(Person);
})();
