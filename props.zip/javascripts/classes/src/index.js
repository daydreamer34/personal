import Person from './personClass';

const person = new Person();
person.printMyName();
person.printName();
person.printAge();
person.printGender();
