import Human from './humanClass';

export default class Person extends Human {
    constructor() {
        super();
        this.name = 'Selva';
        this.age = 34;
    }

    printMyName() {
        console.log(this.name);
    }
}
