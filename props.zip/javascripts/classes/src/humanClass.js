export default class Human {
    constructor() {
        this.name = 'Human';
        this.age = '25';
        this.gender = 'Male';
    }

    printName() {
        console.log(`Name ${this.name}`);
    }
    printAge() {
        console.log(`Name ${this.age}`);
    }
    printGender() {
        console.log(`Name ${this.gender}`);
    }
}
