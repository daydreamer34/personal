// const customElements = function () {};
// const cache = {}
// customElements.getData = (url) => {
//     if (this.cache[url]) {
//         this.data = this.cache[url];
//         this.dispatchEvent(new Event('load'));
//     } else {
//         fetch(url).then((result)=> result.ArrayBuffer()).then(data=>{
//             this.cache[url] = data;
//             this.data = data;
//             this.dispatchEvent(new Event('load'));
//         })
//     }
// }

// console.log(customElements.getData('https://jsonplaceholder.typicode.com/todos/1'));


const customElements = function () {}

customElements.prototype.getData = (url) => {
    if (this.caches[url]) {
        this.data = this.caches[url];
        this.data = data;
    } else {
        fetch(url)
        .then(result =>  result.json())
        .then(data => {
            this.caches[url] = data;
            this.data = data;
        });
    }
}


test1 = new customElements();
console.log(test1.getData('https://jsonplaceholder.typicode.com/todos/1'));