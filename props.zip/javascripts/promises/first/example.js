var a;
var promiese1 = new Promise((resolve, reject) => {
	if (a == 'done') {
		resolve('Success');
	} else {
		reject('Failed');
	}
});

promiese1
	.then((message) => {
		console.log('This is inside the resolve then');
		console.log(message);
	})
	.catch((error) => {
		console.log('This is inside the reject catch');
		console.log(error);
	});
console.log(
	"I'm executed first before the promise response printed ",
	promiese1
);

function makeRequest(params) {
	return new Promise((resolve, reject) => {
		if (params == 'Done') {
			resolve('Success');
		} else {
			reject('Failed');
		}
	});
}

function processRequest(response) {
	return new Promise((resolve, reject) => {
		resolve('This is the resolve request of ' + response + ' response');
	});
}

async function doWork() {
	try {
		var response = await makeRequest('Done');
		var processedResponse = await processRequest(response);
		console.log(processedResponse);
	} catch (error) {
		console.log(error);
	}
}
doWork();
console.log('after calling the doWork function');

let promise = new Promise((resolve, reject) => {
	let test = Math.floor(Math.random() * 2);
	console.log(test);
	setTimeout(() => {
		console.log(test, !!test);
		if (!!test) {
			resolve('test');
		}
		return reject('test');
	}, 1000);
});
promise
	.then((result) => console.log(`Success ${result}`))
	.catch((result) => console.log(`Failed ${result}`));

async function WaitAndMayBeReject() {
	await new Promise((r) => setTimeout(r, 1000));

	const isHeads = Boolean(Math.round(Math.random()));

	if (isHeads) return 'Yeah!';
	throw Error('Boom!');
}

async function foo() {
	console.log('Calling foo');
	try {
		return await WaitAndMayBeReject();
	} catch (e) {
		return 'Caught ' + e;
	}
}
//setInterval(function(){ console.log(foo()); },1000);
