function makeRequest(location){
    return new Promise((resolve, reject) => {
        console.log('Making request to '+ location);
        if(location=='Google'){
            resolve('Google says hi..');
        } else {
            reject('We can\'t make request to '+location);
        }
    });
}
function processRequest(response){
    console.log('Processing response....');
    return new Promise((resolve, reject)=>{
        resolve(response);
    });
}

makeRequest('Google').then((response)=>{
    console.log('Sending response to process');
    return processRequest(response);
}).then((processedResponse)=> {
    console.log(processedResponse);
}).catch((error)=>{
    console.log(error);
})