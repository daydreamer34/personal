function foo(){
    console.log('foo');
}

function bar(){
    console.log('bar');
}

function test(){
    console.log('test');
}
export default test;
export {foo, bar};