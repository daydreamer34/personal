import {foo as testing} from './utlis';
import test from './utlis';
import {bar} from './utlis';

testing();
bar();
test();