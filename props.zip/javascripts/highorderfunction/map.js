const items = [
    {name:"Bike", price:500},
    {name:"Car", price:1000},
    {name:"Bus", price:2000},
    {name:"TV", price:100},
    {name:"Speaker", price:50},
    {name:"Book", price:5},
    {name:"Bag", price:30},
    {name:"Laptop", price:200},
    {name:"Toys", price:10},
];

const mappedArray = items.map((item)=> {return item.price; });
console.log(mappedArray);
