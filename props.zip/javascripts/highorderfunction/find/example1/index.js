const HomeServices = {
    productsInfo: [{
            productId: 'BDOBC',
            price: 4,
            image: '/content/dam/britishgas/images/boilers-and-heating/boiler-cover.png',
            inclusionsExclusions: [{
                    info: 'Repairs to your boiler and controls',
                    status: true
                },
                {
                    info: 'Annual boiler service',
                    status: false
                }
            ]
        },
        {
            productId: 'BDOCH',
            price: 8,
            image: '/content/dam/britishgas/images/boilers-and-heating/boiler-and-central-heating-cover.png',
            inclusionsExclusions: [{
                    info: 'Repairs to your boiler and controls',
                    status: true
                },
                {
                    info: 'Repairs to your central heating system',
                    status: true
                },
                {
                    info: 'Annual boiler service',
                    status: false
                }
            ]
        }
    ],
    
    findId: function() { 
        return this.productsInfo.find((item)=> { console.log(item.productId); if(item.productId == 'BDOCH') {  return item.productId+ ', ' + item.price;} });
    }
}
HomeServices.findId();
