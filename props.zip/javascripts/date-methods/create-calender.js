
function calender(year, month) {
	const date = new Date();
	const noofdaysinamonth = new Date(year, month, 0).getDate();
	console.log(noofdaysinamonth);
	const arraydates = [...Array(noofdaysinamonth).keys()].map((day) => {
		return { day: day + 1, date: new Date(year, month - 1, day + 2) };
	});

	return arraydates;
}

console.log(new Date(2021, 8, 1));
console.log(calender(2021, 09));
