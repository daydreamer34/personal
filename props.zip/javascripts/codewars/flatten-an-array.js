const arrays = [1, 2, 3, [10, 9], [4, 5, [6, [7, [8]]]]];

console.log([].concat.apply([], arrays));
console.log([].concat(...arrays));
const flatdeep = (arrays) =>
	arrays.reduce(
		(acc, arr) => acc.concat(Array.isArray(arr) ? flatdeep(arr) : arr),
		[]
	);

console.log(flatdeep(arrays));

const flatArray = (arr) => {
	let flatarr = [];
	let counter = 0;
	while (arr.length > counter) {
		if (Array.isArray(arr[counter])) {
			flatarr.push(...flatArray(arr[counter]));
		} else {
			flatarr.push(arr[counter]);
		}
		counter++;
	}
	return flatarr;
};

console.log(flatArray(arrays));
