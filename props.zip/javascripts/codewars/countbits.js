function countBits(n) {
	return n.toString(2);
}
console.log(countBits(8));
