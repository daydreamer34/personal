const rank = (st, we, n) => {
	const names = st.split(',');
	if (st === '') return 'No participants';
	if (names.length < n) return 'Not enough participants';
	return names
		.map((name, i) => {
			return {
				name,
				total:
					we[i] *
					[...name.toLowerCase()].reduce(
						(a, c) => a + (c.charCodeAt(0) - 'a'.charCodeAt(0) + 1),
						name.length
					),
			};
		})
		.sort((a, b) => b.total - a.total || a.name > b.name)[n - 1].name;
};
console.log(
	rank(
		'Olivai,Samantha,Sophia,Addison,Abigail,Alexander,Sofia,William,Mia,Willaim,Madison,Lily,Aiden,Logan,Liam,Olivia,Avery,Lagon,Daniel,Noah,Chloe,Ella,Ethan,Emily,Lyli,Naoh,Michael',
		[
			2, 3, 6, 6, 2, 6, 5, 1, 5, 2, 1, 5, 5, 1, 5, 6, 4, 6, 3, 2, 1, 4, 2,
			4, 3, 5, 5,
		],
		8
	)
);
