const Helpers = function () {};

Helpers.prototype.test = function () {};

const captializeFirstLetter = (str) => {
	return str.replace(/^./, str[0].toUpperCase());
};

module.exports = {
	...Helpers,
	captializeFirstLetter,
};
