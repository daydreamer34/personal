const Helpers = require('../helpers/helpers');

console.log(`==========================================`);
console.log(`Prototypes`);
console.log(`==========================================`);
const student = {
	id: 123123,
	name: 'selva',
	age: 23,
	grade: 'SSLC',
	marks: [100, 100, 100, 100, 100],
};
for (const key in student) {
	console.log(
		key,
		Helpers.captializeFirstLetter(typeof student[key]),
		student[key]
	);
}
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`1. Conditionally add properties`);
console.log(`==========================================`);
const condition = true;

const person = {
	name: 'Selvakumar',
	...(condition && { age: 34 }),
};
console.log(person);
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`2. Check props exists in an Object`);
console.log(`==========================================`);

console.log('age' in person);
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`3. Dynamic props in an Object`);
console.log(`==========================================`);
var flavor = 'flavor';
const item = {
	name: 'Biscut',
	[flavor]: 'choclate',
};
console.log(item);
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`4. Object desturcturing`);
console.log(`==========================================`);
var flavor = '';
const productItem = {
	name: 'Biscut',
	flavor: 'choclate',
};
console.log(productItem);
const product = 'name';
const { [product]: productName } = productItem;
console.log(productName);
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`Convert to boolean value`);
console.log(`==========================================`);
const stringName = 'Selva';
console.log(!!stringName);
const booleanValue = true;
console.log(!!booleanValue);
console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`False value in Array`);
console.log(`==========================================`);

const falseArray = [false, true, undefined, 0];
console.log(`falseArray in one or more${falseArray.filter(Boolean)}`);
console.log(`falseArray in some ${falseArray.some(Boolean)}`);
console.log(`falseArray in every ${falseArray.every(Boolean)}`);

console.log(`==========================================`);
console.log(``);

console.log(`==========================================`);
console.log(`Flattering Array's of Array's`);
console.log(`==========================================`);

const myArray = [{ id: 1 }, [{ id: 2 }], [{ id: 3 }]];
const numberArray = [1, 2, 3, [4]];
console.log(myArray.flat());
console.log(numberArray.flat());

console.log(`==========================================`);
console.log(``);
