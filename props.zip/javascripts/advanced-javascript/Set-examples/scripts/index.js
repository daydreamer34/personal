var dupIntArray = [1, 2, 2, 6, 3, 4, 2, 3, 5, 1];

var dupStringArray = ["cat", "dog", "tiger", "lion", "cat", "lion" ];

console.log("dupIntArray", dupIntArray);

console.log("dupStringArray", dupStringArray);

var dupRemovedIntArray = [...new Set(dupIntArray)];

console.log("dupRemovedIntArray - [...new Set(dupIntArray)]", dupRemovedIntArray);

var dupRemovedStringArray = [...new Set(dupStringArray)];

console.log("dupRemovedStringArray [...new Set(dupStringArray)]", dupRemovedStringArray);

var setArray = new Set();

setArray.add(1);
setArray.add(3);
setArray.add(1);
setArray.add(2);
setArray.add(1);
setArray.add(2);

console.log("[...setArray]", [...setArray]);

var printSetArray = new Set();

console.log("printSetArray", printSetArray);

printSetArray.add(10);
printSetArray.add(5);
printSetArray.add(8);

console.log("printSetArray After values added", printSetArray);

console.log("has 1", printSetArray.has(1));

console.log("has 5", printSetArray.has(5));

console.log("size", printSetArray.size);

console.log("entries", printSetArray.entries());

console.log("keys", printSetArray.keys());

console.log("values", printSetArray.values());

printSetArray.delete(2);

console.log("after deleted",printSetArray);

console.log("size", printSetArray.size);

printSetArray.clear();

console.log("after cleared", printSetArray);
