var maparray = new Map([[1, 'one'],[2,'two']]);

console.log(maparray);

console.log(maparray.get('one'))