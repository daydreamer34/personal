let data = [
	['The', 'red', 'horse'],
	['Plane', 'over', 'the', 'ocean'],
	['Chocolate', 'ice', 'cream', 'is', 'awesome'],
	['this', 'is', 'a', 'long', 'sentence'],
];

let concateddata = data.map((item) => {
	return item.join(' ');
});

//console.log(concateddata);

concateddata = data.map((item) => {
	if (Array.isArray(item)) {
		return item.reduce((acc, value) => {
			return `${acc} ${value}`;
		});
	}
});

//console.log(concateddata);

let duplicate = [1, 2, 2, 2, 2, 3, 34, 4, 5, 6, 3, 5, 7, 8, 4, 7, 8];

//console.log(duplicate);

let unique = new Set(duplicate);
//console.log(unique);
//console.log([...unique]);

unique = duplicate.filter((a, i) => {
	console.log(a, i, duplicate.indexOf(a));
}, 0);
