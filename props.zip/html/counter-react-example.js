import { useState } from 'react';

const counter = (count = { value: 0 }, action) => {
	switch (action.type) {
		case 'INCREMENT':
			return { value: count.value + 1 };
		case 'DECREMENT':
			return { value: count.value - 1 };
		default:
			return count;
	}
};
export default App = () => {
	const [count, setCount] = useState(counter(undefined, {}));
	const dispatch = (action) => {
		setCount(counter(count, action));
	};
	const increment = () => {
		dispatch({ type: 'INCREMENT' });
	};
	const decrement = () => {
		dispatch({ type: 'DECREMENT' });
	};

	return (
		<div>
			<span>{count.value}</span>
			<div className="buttonContainer">
				<button onClick={increment}>+</button>
				<button onClick={decrement}>-</button>
			</div>
		</div>
	);
};
