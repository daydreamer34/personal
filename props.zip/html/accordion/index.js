const accordion = Array.from(document.getElementsByClassName('container'));
accordion.map((element) => {
	element.addEventListener('click', (target) => {
		// element.classList.toggle('active'); this also will work
		target.currentTarget.classList.toggle('active');
	});
});
