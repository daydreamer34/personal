test = false;
var arr = [1, 2];
const [x, y] = [arr];
if (test == false) {
    console.log(test);
    console.log(x, y);
}
