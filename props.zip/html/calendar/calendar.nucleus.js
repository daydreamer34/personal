import { html, css, LitElement } from 'lit-element';
import styles from './styles.less';
import { dateFromISOString, dateToISOString, getMonthData, months, moveDate, weekDays, weekDaysFull, firstDayOfMonth } from './../utils/date';

class nsCalendar extends LitElement {
	// Public property API that triggers re-render (synced with attributes)

	get month() {
		return this._month;
	}

	set month(value) {
		const oldVal = this._month;
		this._month = value;
		this.updateStartDate();
		this.requestUpdate('month', oldVal);
	}

	get year() {
		return this._year;
	}

	set year(value) {
		const oldVal = this._year;
		this._year = value;
		this.updateStartDate();
		this.requestUpdate('year', oldVal);
	}

	get startDate() {
		return this._startDate;
	}

	updateStartDate() {
		const today = new Date();
		if (!this._year) {
			this._year = today.getFullYear();
		}
		if (!this._month) {
			this._month = today.getMonth() + 1;
		}
		this._startDate = new Date(this._year, this._month - 1);
		this.cursorDate = new Date();
		this.cursorDate.setTime(this._startDate.getTime());
	}

	constructor() {
		super();
		this.renderCount = 0;
		this.numMonths = 1;
		this.updateStartDate();
		this.cursorDate = new Date();
		this.hasHadFocus = false;
		this.keyDownHandler = this.keyDownHandler.bind(this);
		this.keyUpHandler = this.keyUpHandler.bind(this);
		this.cellClickHandler = this.cellClickHandler.bind(this);
		this.prevMonthHandler = this.prevMonthHandler.bind(this);
		this.nextMonthHandler = this.nextMonthHandler.bind(this);
	}

	addEventListeners() {
		this.shadowRoot.querySelectorAll('td').forEach((td) => {
			if (!td.classList.contains('disabled') && !td.classList.contains('empty')) {
				// && !td.classList.contains('selected')
				td.addEventListener('click', this.cellClickHandler);
			}
		});
	}

	removeEventListeners() {
		this.shadowRoot.querySelectorAll('td').forEach((td) => {
			td.removeEventListener('click', this.cellClickHandler);
		});
	}

	cellClickHandler(event) {
		this.selectCell(event.currentTarget, true);
	}

	getCellByDate(date) {
		const cell = this.shadowRoot.querySelector(`[data-date="${dateToISOString(date)}"]`);
		return cell;
	}

	highlightCellByDate(date) {
		const cell = this.getCellByDate(date);
		if (this.cursorDate.getMonth() !== date.getMonth()) {
			// If we're trying to changing month and going past max or before min month then return
			if (
				this.cursorDate < date &&
				this.maxDate &&
				this.cursorDate.getMonth() === dateFromISOString(this.maxDate).getMonth() &&
				this.cursorDate.getFullYear() === dateFromISOString(this.maxDate).getFullYear()
			) {
				return;
			} else if (
				this.cursorDate > date &&
				this.minDate &&
				this.cursorDate.getMonth() === dateFromISOString(this.minDate).getMonth() &&
				this.cursorDate.getFullYear() === dateFromISOString(this.minDate).getFullYear()
			) {
				return;
			}
			this.month = date.getMonth() + 1;
			this.year = date.getFullYear();

			this.cursorDate = date;
			this.keepFocus = true;
		}

		if (cell && this.selectOnFocus && !cell.classList.contains('disabled')) {
			this.selectedDate = date;
		}

		if (cell) {
			this.cursorDate = date;
			this.focusDate = dateToISOString(this.cursorDate);
			this.requestUpdate();
		}
	}

	keyDownHandler(event) {
		if (!event) {
			event = window.event;
		}
		let code;
		if (event.charCode && event.keyCode === 0) {
			code = event.charCode;
		} else {
			code = event.keyCode;
		}

		if (code > 36 && code < 41) {
			event.preventDefault();
		}

		const cell = this.shadowRoot.querySelector(`td[data-date="${dateToISOString(this.cursorDate)}"]`);

		switch (code) {
			case 13: //'Enter'
				this.selectCell(cell, true);
				event.preventDefault();
				break;
			case 39: //'ArrowRight'
				this.highlightCellByDate(moveDate(this.cursorDate, 1));
				break;
			case 37: //'ArrowLeft'
				this.highlightCellByDate(moveDate(this.cursorDate, -1));
				break;
			case 40: //'ArrowDown'
				this.highlightCellByDate(moveDate(this.cursorDate, 7));
				break;
			case 38: //'ArrowUp'
				this.highlightCellByDate(moveDate(this.cursorDate, -7));
				break;
			default:
				return;
		}
	}

	keyUpHandler(event) {
		if (!event) {
			event = window.event;
		}
		let code;
		if (event.charCode && event.keyCode === 0) {
			code = event.charCode;
		} else {
			code = event.keyCode;
		}

		const cell = this.shadowRoot.querySelector(`td[data-date="${dateToISOString(this.cursorDate)}"]`);

		// Space
		if (code === 32) {
			this.selectCell(cell, true);
			event.preventDefault();
		}
	}

	selectCell(cell, click) {
		if (cell.classList.contains('disabled')) {
			return;
		}

		const date = dateFromISOString(cell.dataset.date);
		date.setHours(12);

		let dispatch = false;
		if (click) {
			const isoDate = this.selectedDate ? dateToISOString(this.selectedDate) : '';
			dispatch = isoDate !== cell.dataset.date;
			this.selectedDate = this.cursorDate = date;
		}

		if (dispatch) {
			this.dispatchEvent(new CustomEvent('change'));
		}
		this.requestUpdate();
	}

	monthTable(date) {
		const days = getMonthData(date);
		const month = date.getMonth();
		const isoToday = dateToISOString(new Date());
		const isoSelectedDate = this.isoSelectedDate || (this.selectedDate ? dateToISOString(this.selectedDate) : null);
		const isoCursorDate = this.cursorDate ? dateToISOString(this.cursorDate) : null;
		let table = `<table role="grid">`;
		table += `<caption>${months[month]} ${date.getFullYear()}</caption>`;
		table += `<thead><tr>`;
		weekDays.forEach((day, index) => {
			table += `<th aria-label="${weekDaysFull[index]}">${day}</th>`;
		});
		table += `</tr></thead>`;
		for (let w = 0; w < 6; w++) {
			// Calcuate if we're on next month here, if so dont render last row
			const weekMonth = days[w * 7].getMonth();
			if (w > 3 && weekMonth !== month) {
				break;
			}
			table += `<tr>`;
			for (let d = 0; d < 7; d++) {
				const date = days[d + w * 7];
				let style = date.getMonth() === month ? `this-month` : `another-month`;
				let dataCols = '';
				if (style.indexOf('this-month') !== -1) {
					dataCols = `data-col="${d}" data-row="${w}" `;
				}
				style += ' date';

				const isoDate = dateToISOString(date);
				if (isoSelectedDate === isoDate) {
					style += ' selected';
				}

				if (isoCursorDate === isoDate) {
					style += ' highlighted';
				}

				let tabIndex = 0;

				if (!this.enabledDates && this.disabledDates && this.disabledDates.includes(isoDate)) {
					style += ' disabled';
					tabIndex = -1;
				}

				if (this.enabledDates) {
					let addDisabledClass = true;
					tabIndex = -1;
					if (this.enabledDates.includes(isoDate)) {
						addDisabledClass = false;
						tabIndex = 0;
					}
					if (addDisabledClass) {
						style += ' disabled';
					}
				}

				if (isoDate < this.minDate || isoDate > this.maxDate) {
					style += ' disabled';
				}

				if (style.indexOf('disabled') === -1) {
					style += ' enabled';
				}

				if (isoDate === isoToday) {
					style += ' today';
				}

				if (!this.selectedDate && isoDate === this.initDate) {
					style += ' selected';
				}

				const ariaColIndex = d + 1;
				const cellContent = date.getMonth() === month ? `<div class="disc"><div class="circle"><span>${date.getDate()}</span></div></div>` : `${date.getDate()}`;
				const formattedDate = `${date.getDate()} ${months[date.getMonth()]}, ${date.getFullYear()}`;
				if (style.indexOf('this-month') !== -1) {
					table += `<td role="gridcell" class="${style}" tabindex="${tabIndex}" aria-colindex="${ariaColIndex}" ${dataCols} ${
						style.indexOf('disabled') !== -1 ? 'aria-disabled="true"' : ''
					} data-date="${isoDate}" aria-label="${formattedDate}">${cellContent}</td>`;
				} else {
					table += `<td class="empty" aria-colindex="${ariaColIndex}">&nbsp;</td>`;
				}
			}
			table += `</tr>`;
		}
		table += `</table>`;
		return table;
	}

	get calendar() {
		let html = `<div class="calendar">`;
		const date = new Date();
		date.setTime(this._startDate.getTime());
		for (let i = 0; i < this.numMonths; i++) {
			html += '<div class="month">' + this.monthTable(date) + '</div>';
			date.setMonth(date.getMonth() + 1);
		}
		html += `</div>`;
		return html;
	}

	get navigation() {
		const date = new Date();
		date.setTime(this._startDate.getTime());
		date.setMonth(date.getMonth() - 1);
		const prev = months[date.getMonth()];
		let prevDisabled = '';
		let nextDisabled = '';

		// if minDate && minDate > firstDate of this month then disable prev
		if (this.minDate) {
			if (dateFromISOString(this.minDate) > firstDayOfMonth(this._startDate)) {
				prevDisabled = 'disabled ';
			}
		}

		// Check maxDate is not less than first day of next month
		date.setMonth(date.getMonth() + this.numMonths + 1);
		if (this.maxDate) {
			if (dateFromISOString(this.maxDate) < firstDayOfMonth(date)) {
				nextDisabled = 'disabled ';
			}
		}

		const next = months[date.getMonth()];
		return `<nav class="navigation">
      <button id="previous-month-button" ${prevDisabled} title="Previous Month ${prev}">
        <ns-icon type="chevron-left"></ns-icon>
      </button>
      <button id="next-month-button" ${nextDisabled} title="Next Month ${next}">
        <ns-icon type="chevron-right"></ns-icon>
      </button>
    </nav>`;
	}

	firstUpdated() {
		this.addEventListener('focus', () => {
			// This is to stop the component stealing focus
			this.hasHadFocus = true;
		});
	}

	prevMonthHandler(event) {
		event.preventDefault();
		this._startDate.setMonth(this._startDate.getMonth() - 1);
		this.focusSelector = '#previous-month-button';
		this.requestUpdate();
	}

	nextMonthHandler(event) {
		event.preventDefault();
		this._startDate.setMonth(this._startDate.getMonth() + 1);
		this.focusSelector = '#next-month-button';
		this.requestUpdate();
	}

	updated() {
		this.shadowRoot.querySelector('#previous-month-button').addEventListener('click', this.prevMonthHandler);
		this.shadowRoot.querySelector('#next-month-button').addEventListener('click', this.nextMonthHandler);

		const tables = this.shadowRoot.querySelectorAll('table');
		tables.forEach((table) => {
			table.removeEventListener('keydown', this.keyDownHandler);
			table.addEventListener('keydown', this.keyDownHandler);

			table.removeEventListener('keyup', this.keyUpHandler);
			table.addEventListener('keyup', this.keyUpHandler);

			table.querySelectorAll('tr').forEach((tr) => {
				tr.querySelectorAll('td, th').forEach((td) => {
					td.addEventListener('focus', (event) => {
						this.cursorDate = dateFromISOString(event.target.dataset.date);
						this.focusSelector = null;
						if (this.fromTab && this.selectOnFocus) {
							this.selectCell(event.currentTarget, true);
						}
					});
				});
			});

			this.removeEventListeners();
			this.addEventListeners();

			if (this.focusSelector) {
				this.shadowRoot.querySelector(this.focusSelector).focus();
			}

			// Highlight Cursor Date after render
			if (this.hasHadFocus) {
				this.fromTab = this.keepFocus;
				const cell = this.getCellByDate(this.cursorDate);

				if (cell) {
					setTimeout(() => {
						cell.focus();
					}, 10);
				}

				this.fromTab = true;
				this.keepFocus = false;
			}

			if (this.focusDate !== 'undefined' && this.focusDate && this.focusDate.length === 10) {
				const cell = this.getCellByDate(dateFromISOString(this.focusDate));
				if (cell) {
					setTimeout(() => {
						cell.focus();
					}, 10);
					this.focusDate = null;
				}
			}
		});
	}

	render() {
		this.renderCount += 1;
		return html([
			`<div>
      ${this.navigation}
      ${this.calendar}
      </div>
      `,
		]);
	}
}
customElements.define('ns-calendar', nsCalendar);
