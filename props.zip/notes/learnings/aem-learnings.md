AEM Learning
Run aem instance:

java -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=8000 aem-author-p4502.jar

