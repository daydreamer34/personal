Unit testing
Component testing
Smoke testing
Sanity testing
Regression testing
Integration testing
API testing
UI testing
System testing
White-box testing
Black-box testing
Acceptance testing
Alpha testing
Beta testing
Production testing

# Unit testing

     Unit testing a is way that we make sure the individual parts application works properly on their own. Unit testing validates the function of a unit, This testing type provides the foundation for more complex integrated software.

# Integration testing

    Integration testing is often done in concert with unit testing. Through integration testing, QA professionals verify that individual modules of code work together properly as a group. Through integration testing, testers ensure these components operate and communicate together seamlessly.

# System testing(end to end testing)

    With system testing, QA professionals test the software in its entirety, as a complete product. With this type of functional testing, testers validate the complete and integrated software package to make sure it meets requirements.

# Regression testing

    When developers commit new code or change a feature, you run regression tests to make sure the software still functions as expected. Regression testing helps maintain a stable product while changes are made to it. Regression tests are often automated.

    ## Example
        Pay with Rewards added and make sure all the other payment methods works correctly

# Acceptance testing

    The purpose of acceptance testing is purely to ensure that the end user can achieve the goals set in the business requirements. Not focus on functionality of specific features, acceptance testing involves reviewing the application flow and end-to-end experience.
