Hoisting

    JavaScript Hoisting refers to the process whereby the interpreter allocates memory for variable and function declarations prior to execution of the code. Declarations that are made using var are initialized with a default value of undefined. Declarations made using let and const are not initialized as part of hoisting.

    Conceptually hoisting is often presented as the interpreter "splitting variable declaration and initialization, and moving (just) the declarations to the top of the code". This allows variables to appear in code before they are defined. Note however, that any variable initialization in the original code will not happen until the line of code is executed.

    var hoisted = "foo" in this;
    console.log(`'foo' name ${hoisted ? "is" : "is not"} hoisted. typeof foo is ${typeof foo}`);
    if (false) {
        function foo(){ return 1; }
    }

Closure and variable scope

Explain this keyword in JavaScript.

    The this keyword evaluates to the value of the ThisBinding of the current execution context.

    A function's this keyword behaves a little differently in JavaScript compared to other languages. 
    It also has some differences between strict mode and non-strict mode.

Difference between object creation by Object constructor and Object.create()

Difference between function declaration by funcation expression

    function declaration
        A function created with a function declaration is a Function object and has all the properties, methods and behavior of Function objects.

        By default, functions return undefined.

        const hoisted = "foo" in this;
        console.log(hoisted, typeof foo);
        if(false){
            function foo() {
                return 1;
            }
        }

    The main difference between a function expression and a function declaration is the function name, which can be omitted in function expressions to create anonymous functions

Call, Apply, Bind

    Call and Apply both invoke the function immideately and create a context with a given object. (may be this or any other object). The diference between these two are the arguments. indiduval or an array of arguments

    Bind - Which is slightly different, It returns a copy of the function and it will be called anywhere later. And the arguments are indiduval.

Prototypal inheritence

    Prototypal inheritance refers to the ability to access the object properties from another object. We use a JavaScript prototype to add new properties and methods to an existing object constructor.

Classical vs Prototypal inheritance

    In classical OO programming, there are two types of abstractions: classes and objects. An object is an abstraction of a real world entity, whereas a class is a generalization of an object. For example, a Vehicle is a generalization of a Car. Hence, cars (class) inherit from vehicles (object).

    In prototypal inheritance, objects are abstractions of either real world entities (in which case they are simply called objects) or other objects (in which case they are called prototypes of those objects which they abstract). Hence, a prototype is a generalization.

    The difference between classical inheritance and prototypal inheritance is that classical inheritance is limited to classes inheriting from other classes while prototypal inheritance supports the cloning of any object using an object linking mechanism. Without getting into too much of the nitty-gritty details, a prototype basically acts as a template for other objects, whether they are extending the base object or not.

Prototype chain

    Every object has a prototype which is a link the parent object, this structure is called prototype chain.

    When it comes to inheritance, JavaScript only has one construct: objects. Each object has a private property which holds a link to another object called its prototype. That prototype object has a prototype of its own, and so on until an object is reached with null as its prototype. By definition, null has no prototype, and acts as the final link in this prototype chain.

Promise

    A promise is an object that may produce a single value some time in the future with either a resolved value or a reason that it’s not resolved(for example, network error).

    In other words, promise in javascript is a special object that links the producers and consumers together to handle the asynchronous operations

    Promise object repersents the eventaul completion or failure of an asynchronous operations and its resulting value.

    why promise

        Promises are used to handle asynchronous operations. They provide an alternative approach for callbacks by reducing the callback hell and writing the cleaner code.

        It will be in one of the 3 possible states: fulfilled, rejected, or pending.

        Promise.resolve(), Promise.reject(), Promise.prototype.then(), Promise.prototype.catch(), Promise.prototype.finally(), Promise.all(), Promise.allSettled(), Promise.any(), Promise.race(),

    What is promise chaining

        The process of executing a sequence of asynchronous tasks one after another using promises is known as Promise chaining.
        Let's take an example of promise chaining for calculating the final result,

        new Promise(function(resolve, reject) {setTimeout(() => resolve(1), 1000);
        }).then(function(result) {
            console.log(result); // 1
            return result * 2;
        }).then(function(result) {
            console.log(result); // 2
            return result * 3;
        }).then(function(result) {
            console.log(result); // 6
            return result * 4;
        });

What is a callback function

    A callback function is a function passed into another function as an argument. This function is invoked inside the outer function to complete an action.

Why do we need callbacks

    The callbacks are needed because javascript is an event driven language. That means instead of waiting for a response javascript will keep executing while listening for other events. Let's take an example with the first function invoking an API call(simulated by setTimeout) and the next function which logs the message.

What are server-sent events

    Server-sent events (SSE) is a server push technology enabling a browser to receive automatic updates from a server via HTTP connection without resorting to polling. These are a one way communications channel - events flow from server to client only. This has been used in Facebook/Twitter updates, stock price updates, news feeds etc.

How do you receive server-sent event notifications

    The EventSource object is used to receive server-sent event notifications. For example, you can receive messages from server as below,

What is the purpose of the array slice method

    The slice() method returns the selected elements in an array as a new array object. It selects the elements starting at the given start argument, and ends at the given optional end argument without including the last element. If you omit the second argument then it selects till the end.
        Some of the examples of this method are,
        let arrayIntegers = [1, 2, 3, 4, 5];
        let arrayIntegers1 = arrayIntegers.slice(0,2); // returns [1,2]
        let arrayIntegers2 = arrayIntegers.slice(2,3); // returns [3]
        let arrayIntegers3 = arrayIntegers.slice(4); //returns [5]
        Note: Slice method won't mutate the original array but it returns the subset as a new array.

What is the purpose of the array splice method

        The splice() method is used either adds/removes items to/from an array, and then returns the removed item. The first argument specifies the array position for insertion or deletion whereas the optional second argument indicates the number of elements to be deleted. Each additional argument is added to the array.
        Some of the examples of this method are,
            let arrayIntegersOriginal1 = [1, 2, 3, 4, 5];
            let arrayIntegersOriginal2 = [1, 2, 3, 4, 5];
            let arrayIntegersOriginal3 = [1, 2, 3, 4, 5];
            let arrayIntegers1 = arrayIntegersOriginal1.splice(0,2);
            // returns [1, 2]; original array: [3, 4, 5]
            let arrayIntegers2 = arrayIntegersOriginal2.splice(3);
            // returns [4, 5]; original array: [1, 2, 3]
            let arrayIntegers3 = arrayIntegersOriginal3.splice(3, 1, "a", "b", "c");
            //returns [4]; original array: [1, 2, 3, "a", "b", "c", 5]
            Note: Splice method modifies the original array and returns the deleted array.

What is the difference between slice and splice

    Some of the major difference in a tabular form
        Slice
            Doesn't modify the original array(immutable)
            Returns the subset of original array
            Used to pick the elements from array
        Splice
            Modifies the original array(mutable)
            Returns the deleted elements as array
            Used to insert or delete elements to/from array

Writing code for Array or String polyfills
Memoization function
debounce function
Explain event delegation.
Can you give an example of one of the ways that working with this has changed in ES6?
What's the difference between a variable that is: null, undefined or undeclared?
What language constructions do you use for iterating over object properties and array items?
Can you describe the main difference between the Array.forEach() loop and Array.map() methods and why you would pick one versus the other?
What's a typical use case for anonymous functions?
What's the difference between host objects and native objects?
Explain the difference between: function Person(){}, var person = Person(), and var person = new Person()?
Explain the differences on the usage of foo between function foo() {} and var foo = function() {}

What's the difference between feature detection, feature inference, and using the UA string?

Describe event bubbling.
Describe event capturing.
What's the difference between an "attribute" and a "property"?
What are the pros and cons of extending built-in JavaScript objects?
What is the difference between == and ===?

    JavaScript provides both strictand type-convertion on (===, !==) , only equality comparison when using (==, !=).

Explain the same-origin policy with regards to JavaScript.
Why is it called a Ternary operator, what does the word "Ternary" indicate?
What is strict mode? What are some of the advantages/disadvantages of using it?
What are some of the advantages/disadvantages of writing JavaScript code in a language that compiles to JavaScript?
What tools and techniques do you use debugging JavaScript code?
Explain the difference between mutable and immutable objects.
What is an example of an immutable object in JavaScript?
What are the pros and cons of immutability?
How can you achieve immutability in your own code?
Explain the difference between synchronous and asynchronous functions.
What is event loop?
What is the difference between call stack and task queue?
What are the differences between variables created using let, var or const?
What are the differences between ES6 class and ES5 function constructors?
Can you offer a use case for the new arrow => function syntax? How does this new syntax differ from other functions?
What advantage is there for using the arrow syntax for a method in a constructor?
What is the definition of a higher-order function?
Can you give an example for destructuring an object or an array?
Can you give an example of generating a string with ES6 Template Literals?
Can you give an example of a curry function and why this syntax offers an advantage?
What are the benefits of using spread syntax and how is it different from rest syntax?
How can you share code between files?
Why you might want to create static class members?
What is the difference between while and do-while loops in JavaScript?
