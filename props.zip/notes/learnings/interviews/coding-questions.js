// Evaluating the max/min value from an n-array using Math.max function

const arr = [10, 20, 30, 15, 25, 45, 55, 65, 5];
Math.max(...arr);

// Swapping values of two variables using destructuring

let a = 10;
let b = 20;
[a, b] = [b, a];
console.log(a, b);

// Executing multiple promises sequentially

var arr = [1, 2, 3, 4, 5, 6];

let myPromise = (num) => {
	return new Promise((resolve) => {
		setTimeout(() => {
			resolve(`${num}`);
		}, 1000);
	});
};

myPromise(1).then((r)=>console.log(r));

arr.reduce((promise, number) => {
	promise.then(() => myPromise(number));
}, Promise.resolve());

[1, 2, 3, 4].reduce((promise, value) => {
	return new Promise((resolve) => {
		resolve(
			promise.then(
				() =>
					
			)
		);
	});
}, Promise.resolve());

// Question: What is the value of foo?

var foo = 10 + '20';
// Question: What will be the output of the code below?

console.log(0.1 + 0.2 == 0.3);
// Question: How would you make this work?

add(2, 5); // 7
add(2)(5); // 7
// Question: What value is returned from the following statement?

"i'm a lasagna hog".split('').reverse().join('');
// Question: What is the value of window.foo?

window.foo || (window.foo = 'bar');
// Question: What is the outcome of the two alerts below?

var foo = 'Hello';
(function () {
	var bar = ' World';
	alert(foo + bar);
})();
alert(foo + bar);
// Question: What is the value of foo.length?

var foo = [];
foo.push(1);
foo.push(2);
// Question: What is the value of foo.x?

var foo = { n: 1 };
var bar = foo;
foo.x = foo = { n: 2 };
// Question: What does the following code print?

console.log('one');
setTimeout(function () {
	console.log('two');
}, 0);
Promise.resolve().then(function () {
	console.log('three');
});
console.log('four');
// Question: What is the difference between these four promises?

doSomething().then(function () {
	return doSomethingElse();
});

doSomething().then(function () {
	doSomethingElse();
});

doSomething().then(doSomethingElse());

doSomething().then(doSomethingElse);
// Question: What will the code below output to the console and why?

(function () {
	var a = (b = 3);
})();

console.log('a defined? ' + (typeof a !== 'undefined'));
console.log('b defined? ' + (typeof b !== 'undefined'));
// Question: Consider the two functions below. Will they both return the same thing? Why or why not?

function foo1() {
	return {
		bar: 'hello',
	};
}

function foo2() {
	return;
	{
		bar: 'hello';
	}
}
