# Agile

    Agile is a set of practices intended to improve the effectiveness of software development professionals, teams, and organizations. It involves discovering requirements and developing solutions.

    Agile in Software Development is a set of methods and practices where solutions evolve through collaboration between self-organizing, cross-functional teams.

    Brainstrom
        Phase 1: Requirement Analysis
        Phase 2: Fesubility Study
    Designing
        Planning the archtectural design

    Develop

    Test

    Deploy

    Do it Again

    Agile methodologies are the conventions that a team chooses to follow in a way that follows Agile values and principles.

    Acceptance Testing, ATDD, Backlog, Backlog Grooming, BDD, Continuous Deployment, Continuous Integration, Definition of Done, Definition of Ready, Exploratory Testing, Given When Then, Incremental Development, Iterative Development, Kanban, Kanban Board, Pair Programming, Planning Poker, Product Owner, Scrum, Scrum Master, Story Mapping, TDD, Timebox, Ubiquitous Language, Unit Testing, Usability Testing, User Stories, 3 C’s

# Why Agile is used in software development?

    With Agile software development, teams can quickly adapt to requirements changes without negatively impacting release dates. Not only that, Agile helps reduce technical debt, improve customer satisfaction and deliver a higher quality product.

# Agile retrospective team

    An Agile retrospective is a meeting that's held at the end of an iteration in Agile software development (ASD ). During the retrospective, the team reflects on what happened in the iteration and identifies actions for improvement going forward

    A retrospective is a meeting held after a product ships to discuss what happened during the product development and release process, with the goal of improving things in the future based on those learnings and conversations.

# Agile software development principles

    The Manifesto for Agile Software Development is based on twelve principles:[23]

        1. Customer satisfaction by early and continuous delivery of valuable software.
        2. Welcome changing requirements, even in late development.
        3. Deliver working software frequently (weeks rather than months)
        4. Close, daily cooperation between business people and developers
        5. Projects are built around motivated individuals, who should be trusted
        6. Face-to-face conversation is the best form of communication (co-location)
        7. Working software is the primary measure of progress
        8. Sustainable development, able to maintain a constant pace
        9. Continuous attention to technical excellence and good design
        10. Simplicity—the art of maximizing the amount of work not done—is essential
        11. Best architectures, requirements, and designs emerge from self-organizing team9
        12. Regularly, the team reflects on how to become more effective, and adjusts acco10ding22
