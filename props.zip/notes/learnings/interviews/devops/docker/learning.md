Main concepts 

    Docker file
    Docker image
    Docker containers


