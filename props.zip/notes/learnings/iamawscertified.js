
var fundtoadvan     = "https://aws.amazon.com/partners/training/"; // there video
var coursedetails   = "https://cloudacademy.com/blog/aws-certification-exams-what-to-expect/";
var bestcourses     = "https://javarevisited.blogspot.com/2019/05/top-5-courses-to-crack-aws-solutions-architect-associate-certification-exam-SAA-C01.html";
const iamawsceritified = [{
        "Udemy": {
            "Solution Architect​": {
                "links": "https://www.udemy.com/course/amazon-certified-solutions-architect-professional/?ranMID=39197&ranEAID=JVFxdTr9V80&ranSiteID=JVFxdTr9V80-29l8raRApmrdUyVeZgmT1w&LSNPUBID=JVFxdTr9V80"
            },
            "AWS Developer​": {
                "links": ""
            },
            "AWS SysOps Administrator​": {
                "links": ""
            }
        },  
        "APN Portal​": {
            "Exam Prep and Learning​": {
                "links": "https://aws.amazon.com/certification/certification-prep/",
                "links": "https://www.aws.training/LearningLibrary?&search=&tab=view_all"​
            },
            "Solution Architect​": {
                "links": "https://www.aws.training/learningobject/curriculum?id=20685"
            },
            "AWS Developer​": {
                "links": "https://www.aws.training/learningobject/curriculum?id=19185"
            },
            "AWS SysOps Administrator​": {
                "links": "https://www.aws.training/learningobject/video?id=27486"
            }
        }
    },
    {
        "PluralSight​": {
            "Solution Architect": ​{
                "links": "https://www.pluralsight.com/courses/aws-certified-solutions-architect-associate"
            },
            "AWS Developer​": ​{
                "links": "https://www.pluralsight.com/paths/aws-certified-developer"
            },
            "Identity and Access Management on AWS​": ​{
                "links": "https://www.pluralsight.com/paths/identity-and-access-management-on-aws"
            }
        }
    },
    {
        "Cloud Academy​": {
            "Solution Architect": ​{
                "links": "https://cloudacademy.com/learning-paths/cloud-academy-solutions-architect-associate-certification-v152-184/"
            },
            "AWS Developer​": ​{
                "links": "https://cloudacademy.com/learning-paths/developer-associate-certification-preparation-for-aws-june-2018-241/"
            },
            "AWS SysOps Administrator​": ​{
                "links": "https://cloudacademy.com/learning-paths/sysops-administrator-associate-certification-preparation-for-aws-2018-295/"
            }
        }
    }
]

