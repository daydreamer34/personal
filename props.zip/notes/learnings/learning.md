Selva you want to be top!
Final list frameworks were
	- Express + Prisma
	- KoaJ
	- BlitzJS
	- RedwoodJS
	- NestJS
	- SailsJS
	- Adonis
	- NextJS
This week goal from now
	React- MERN P1 - ngc9gnGgUdA
	React- MERN P1 - I6ypD7qv3Z8
	Node Express App- l8WPWK9mS5M
	Node Express App - _1xa8Bsho6A - 
Free code camp
	mrHNSanmqQ4
Javascript Topics
	forEach
	filter
	map
	reduce
	accessors (getters and setters)
	every
	some
	Object
	getPrototypeOf
	create
	bind
	strict mode
	arrow functions
	template strings
	Promises
	import statement
	let and const
	destructuring
	for..of and for in
	enhanced object literals
	default parameter values
	rest parameters, spread operator
	Map, Set
	WeakMap, WeakSet
	from
	find, findIndex
	startsWith, endsWith, includes
	repeat
	Math, Number
	Array.includes
	async / await
	Object.values and Object.entries
	Rest / Spread properties
	Promise.finally
	for await.. of async iterators
	Array.flat and Array.flatMap
	Promise.allSettled
	globalThis
React 
	Fundamentals:
		* Create React App
		* Function Components
		* Class Components
		* JSX
		* Props and State
		* useState and useEffect Hooks
		* setState and component lifecycle methods
		* Conditional Rendering
		* Lists and keys
		* Building Simple Forms
	Advanced Topics :
		* Context
		* Higher Order Functions
		* Render props
		* Refs
		* Error Boundaries
		* Portals
		* HTTP Requests — GET and POST
		* Hooks: useContext, useReducer, useRef, useMemo, useCallback, Custom hooks
	Ecosystem
		* State Management — Redux/Mobx, Appolo Client
		* Routing — React Router
		* Styling — Styled Components/Emotion, Tailwind CSS, Chakra UI, Material UI, Ant Design
		* Forms — Typescript, Storybook, Reacti18Next, Firebase, Practical React Libraries
		* Next Steps — Gatsby, Next.js, React Native, Flutter
	Tools
		1. SWR
		2. Jotai
		3. Chakra UI
		4. Framer Motion
		5. React Hot Toast
		* react-google-login
		* react-youtube
		* react-facebook-login
		* styled-components
		* react-router-dom
		* react-select
		* redux
		* react-bootstrap
		* react-icons
		* material-ui
		* react-avatar
Fakeflix
https://www.devaradise.com/react-example-projects
https://www.2embed.ru/
https://maxrozen.com/examples-of-large-production-grade-open-source-react-apps
https://overreacted.io/
https://www.teamblind.com/search/react
https://www.teamblind.com/post/New-Year-Gift---Curated-List-of-Top-75-LeetCode-Questions-to-Save-Your-Time-OaM1orEU
https://jacky-jiang.medium.com/react-hooks-are-great-to-reuse-stateful-logic-but-whats-the-missing-piece-d00d044d76ad
https://dmitripavlutin.com/react-useeffect-infinite-loop/
https://ashrith.vercel.app/
https://whatthefuck.is/
https://towardsdatascience.com/lets-create-a-covid-19-tracker-using-react-js-5a3a0265a633
https://cube.dev/blog/building-mongodb-dashboard-using-node.js
https://degreed.com/articles/build-database-relationships-with-node-js-and-mongodb?d=14514443&view=true&utm_source=slack&utm_medium=integration&utm_campaign=regular&utm_content=todayslearning
https://expressjs.com/en/starter/hello-world.html
https://robinpokorny.medium.com/index-as-a-key-is-an-anti-pattern-e0349aece318
https://www.restapitutorial.com/httpstatuscodes.html
https://betterprogramming.pub/build-a-real-time-note-taking-app-in-javascript-bc6e8d149d51
https://www.codelivly.com/best-reactjs-projects-for-beginners/
https://levelup.gitconnected.com/how-to-design-a-system-to-scale-to-your-first-100-million-users-4450a2f9703d
https://amyjandrews.medium.com/5-side-project-ideas-for-web-developers-d28655d17fdd
https://www.youtube.com/embed/I6ypD7qv3Z8
https://www.youtube.com/embed/ngc9gnGgUdA
https://www.youtube.com/watch?v=mrHNSanmqQ4
https://www.youtube.com/watch?v=lKKsjpH09dU&t=1s
https://dev.to/ms_74/authentication-vulnerabilities-15po
https://dev.to/molly/setting-yourself-up-for-interview-success-15b7
https://dev.to/anishkumar/design-patterns-in-javascript-publish-subscribe-or-pubsub-20gf
https://dev.to/farminfarzin/frameworks-war-3mak
https://dev.to/thenerdydev/10-react-projects-every-beginner-should-try-fk9?utm_source=hackertab.dev&utm_medium=post&utm_campaign=home
https://dev.to/devdiscuss/s6-e2-lambda-fargate-ec2-oh-my-an-aws-service-deep-dive
https://dev.to/starbist/you-don-t-need-react-for-building-websites-455f
https://dev.to/dailydevtips1/i-refactored-all-my-articles-2cph
https://dev.to/devpool3000/how-to-build-rest-api-using-node-js-feathers-framework-4pli
https://www.freecodecamp.org/news/how-to-build-a-todo-application-using-reactjs-and-firebase
https://www.freecodecamp.org/news/how-to-build-a-todo-application-using-reactjs-and-firebase/
https://www.freecodecamp.org/news/how-to-find-remote-jobs/
https://www.freecodecamp.org/news/how-to-perform-crud-operations-using-react/
https://medium.com/javascript-scene/master-the-javascript-interview-what-is-functional-programming-7f218c68b3a0
https://medium.com/weekly-webtips/what-is-the-difference-between-a-url-and-a-uri-8d4f473b04b
https://medium.com/live-your-life-on-purpose/how-to-achieve-more-in-a-single-year-than-most-achieve-in-a-lifetime-9c9ab57231b0
https://javascript.plainenglish.io/create-a-restuarant-app-in-2021-5e2da2f146de
https://javascript.plainenglish.io/5-useeffect-infinite-loop-patterns-2dc9d45a253f
https://javascript.plainenglish.io/15-custom-hooks-to-make-your-react-component-lightweight-8b59b122d83a
https://javascript.plainenglish.io/deep-dive-into-tree-shaking-ba2e648b8dcb
https://javascript.plainenglish.io/where-to-store-the-json-web-token-jwt-4f76abcd4577
https://cognizant.udemy.com/course/react-nodejs-express-mongodb-the-mern-fullstack-guide/learn/lecture/16808122#overview
https://cognizant.udemy.com/course/serverless-framework/learn/lecture/19072866#overview
https://cognizant.udemy.com/course/aws-certified-developer-associate-dva-c01/learn/lecture/26100754#overview
https://cognizant.udemy.com/course/serverless-framework/learn/lecture/19420504#overview
https://cognizant.udemy.com/course/learn-javascript-full-stack-from-scratch/learn/lecture/9659044#overview
https://cognizant.udemy.com/course/react-nodejs-express-mongodb-the-mern-fullstack-guide/learn/lecture/16808122#overview
https://cognizant.udemy.com/course/serverless-framework/learn/lecture/19147126#overview
https://cognizant.udemy.com/course/aws-certified-developer-associate-dva-c01/learn/lecture/26100786#overview
https://github.com/yangshun/tech-interview-handbook
https://github.com/daydreamer34/javascript-algorithms
https://github.com/bradtraversy/vanilla-node-rest-api
https://github.com/facebook/fbjs/tree/main/packages/fbjs/src/core
https://github.com/facebook/react/issues/14920#issuecomment-471070149
https://github.com/beaucarnes/restaurant-reviews/tree/master/frontend
https://github.com/adrianhajdin/project_mern_memories/blob/PART_1_and_2/client/src/App.js
https://github.com/adrianhajdin/project_mern_memories/blob/PART_1_and_2/client/src/App.js
https://github.com/beaucarnes/restaurant-reviews/tree/master/frontend
https://github.com/maitraysuthar/rest-api-nodejs-mongodb/
https://github.com/adam-golab/react-developer-roadmap
https://github.com/sudheerj/reactjs-interview-questions
https://gist.github.com/adrianhajdin/d99aaa67124f0de7667fd3937715fb26
https://aws.amazon.com/getting-started/hands-on/build-web-app-s3-lambda-api-gateway-dynamodb/?e=gs2020&p=fullstack&p=gsrc&c=lp_fsd
https://aws.amazon.com/getting-started/learning-path-front-end-developer/?e=rc2020

