# notes
Add my daily notes and tasks into this repository
